module.exports = async function (event, content, cloud) {
  return event.data.data
}
