const envList = []
const isMac = true
module.exports = {
  envList,
  isMac
}
