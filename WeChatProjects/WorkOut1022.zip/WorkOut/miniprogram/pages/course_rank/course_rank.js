Page({
  data: {
    listData: [
      { coachRank: '瑜伽', appointments: 100 },
      { coachRank: '动感单车', appointments: 10 },
      { coachRank: '羽毛球', appointments: 7 },
      // 更多数据...
    ]
  },
  onLoad: function() {
    // 页面加载时执行的初始化代码
  }
});