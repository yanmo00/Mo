Page({
  data: {
    listData: [
      { coachRank: '牛教练', appointments: 100 },
      { coachRank: '王教练', appointments: 10 },
      { coachRank: '张教练', appointments: 7 },
      // 更多数据...
    ]
  },
  onLoad: function() {
    // 页面加载时执行的初始化代码
  }
});