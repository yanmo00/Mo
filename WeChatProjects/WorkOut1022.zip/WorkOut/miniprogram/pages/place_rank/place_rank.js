Page({
  data: {
    listData: [
      { coachRank: '体育馆', appointments: 100 },
      { coachRank: '奥体中心', appointments: 10 },
      { coachRank: '体育中心', appointments: 7 },
      // 更多数据...
    ]
  },
  onLoad: function() {
    // 页面加载时执行的初始化代码
  }
});